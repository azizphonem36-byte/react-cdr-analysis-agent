import { type ChangeEvent, useEffect, useMemo, useRef, useState } from "react";
import {
  AlertCircle,
  BarChart3,
  Bot,
  Clock,
  Download,
  MapPin,
  MessageCircle,
  Phone,
  PieChart,
  Search,
  Send,
  TrendingUp,
  Upload,
  User,
  Zap
} from "lucide-react";

type CdrRecord = Record<string, string>;
type ChatMessage = {
  role: "agent" | "user";
  content: string;
  timestamp: Date;
};
type Stats = {
  totalCalls: number;
  totalDurationMinutes: number;
  averageDurationSec: number;
  topNumbers: [string, number][];
  busiestHourLabel: string;
  hoursDistribution: Array<{ label: string; value: number }>;
  locationCounts: [string, number][];
  topLocationLabel: string;
  longestCall: { label: string; durationMinutes: number; detail: string } | null;
  flaggedCalls: string[];
};

type AgentPersona = {
  id: string;
  title: string;
  tagline: string;
  accent: string;
  tone: string;
};

type ChatMode = "cdr" | "general";


const quickQuestions = [
  "টপ নম্বর?",
  "রাতের কল?",
  "সন্দেহজনক?",
  "পুরো রিপোর্ট?",
  "গড় সময়?",
  "কোন এলাকা?",
  "আজকের খবর?",
  "মোট কল কত?"
];

const agentPersonas: AgentPersona[] = [
  {
    id: "insight",
    title: "Insight Agent",
    tagline: "ডেটা-চালিত ইনসাইট",
    accent: "from-purple-600 to-blue-600",
    tone: "সংক্ষিপ্ত ও তথ্যমুখর"
  },
  {
    id: "guide",
    title: "Guide Agent",
    tagline: "সহানুভূতিশীল ব্যাখ্যা",
    accent: "from-emerald-500 to-teal-500",
    tone: "সহজ ও অনুপ্রেরণামূলক"
  },
  {
    id: "mentor",
    title: "Mentor Agent",
    tagline: "স্ট্র্যাটেজি ও গাইড",
    accent: "from-orange-500 to-pink-500",
    tone: "কৌশলগত ও গভীর বিশ্লেষণ"
  }
];

const generalKnowledge = [
  {
    keywords: ["আবহাওয়া", "weather"],
    response: "ঢাকায় বর্তমানে হালকা মেঘলা; ভোরে হালকা ঝড় হতে পারে। প্রাক-বার্ষিকী ট্রেন্ডে ঠান্ডার সবরকম ডেটা প্রস্তুত রাখুন।"
  },
  {
    keywords: ["সাইবার", "cyber", "সিকিউরিটি"],
    response: "নতুন ডিভাইস অ্যাক্সেস করার আগে মাল্টিফ্যাক্টর যাচাই করুন, এবং CDR থেকে অস্বাভাবিক লোকেশন লুকআপ রেগুলার রাখুন।"
  },
  {
    keywords: ["সরকার", "politics", "রাজনীতি"],
    response: "বাংলাদেশের সরকারি নীতি ঢেউয়ের মতো পরিবর্তিত হয়; তাই কনট্রাক্টে প্রায় সময় টিফিনাইল পয়েন্ট সেট করে রাখুন।"
  },
  {
    keywords: ["help", "সহায়তা", "কিভাবে"],
    response: "প্রশ্নটি যত স্পষ্ট হবে, উত্তর তত বেশি নিখুঁত হবে। ডেটা থাকলে সংশ্লিষ্ট কল নম্বর বা সময় উল্লেখ করুন।"
  }
];

const chatModes: { id: ChatMode; label: string; description: string }[] = [
  { id: "cdr", label: "CDR প্রশ্ন", description: "ফাইল থেকে ডেটা ব্যবহার করে" },
  { id: "general", label: "যেকোনো প্রশ্ন", description: "সাধারণ কথোপকথন" }
];

const parseCsv = (text: string): CdrRecord[] => {
  const rows = text
    .split(/\r?\n/)
    .map(row => row.trim())
    .filter(Boolean);
  const headers = rows[0]?.split(",").map(header => header.trim()) ?? [];
  return rows.slice(1).map(row => {
    const values = row.split(",");
    const record: CdrRecord = {};
    headers.forEach((header, index) => {
      record[header] = values[index]?.trim() ?? "";
    });
    return record;
  });
};

const sanitizeNumber = (record: CdrRecord) =>
  record["Called Number"] ?? record.Called ?? record.Caller ?? record.number ?? record.CalledNumber ?? "Unknown";

const getLocationLabel = (record: CdrRecord) =>
  record.Location ?? record.location ?? record.Area ?? record["Call Center"] ?? "অনির্দিষ্ট";

const parseDuration = (record: CdrRecord) => {
  const raw = record.Duration ?? record.duration ?? record["Call Duration"] ?? "0";
  const clean = raw.replace(/[^\d]/g, "");
  const value = Number(clean);
  return Number.isNaN(value) ? 0 : value;
};

const computeStats = (data: CdrRecord[]): Stats | null => {
  if (!data.length) return null;
  const durations = data.map(parseDuration);
  const totalDurationSeconds = durations.reduce((acc, curr) => acc + curr, 0);
  const averageDurationSeconds =
    totalDurationSeconds === 0 ? 0 : totalDurationSeconds / data.length;
  const totalDurationMinutes = Math.max(1, Math.round(totalDurationSeconds / 60));
  const numberCounts: Record<string, number> = {};
  const hoursMap: Record<string, number> = {};
  const locationMap: Record<string, number> = {};
  data.forEach(record => {
    const primaryNumber = sanitizeNumber(record);
    numberCounts[primaryNumber] = (numberCounts[primaryNumber] || 0) + 1;

    const datePart = record.Date ?? record.date ?? "";
    const timePart = record.Time ?? record.time ?? "";
    const isoString = timePart ? `${datePart}T${timePart}` : datePart;
    const parsed = new Date(isoString);
    if (!Number.isNaN(parsed.getTime())) {
      const label = `${String(parsed.getHours()).padStart(2, "0")}:00`;
      hoursMap[label] = (hoursMap[label] || 0) + 1;
    } else {
      hoursMap["Unknown"] = (hoursMap["Unknown"] || 0) + 1;
    }

    const locationLabel = getLocationLabel(record);
    locationMap[locationLabel] = (locationMap[locationLabel] || 0) + 1;
  });

  const topNumbers = Object.entries(numberCounts).sort((a, b) => b[1] - a[1]);
  const locationCounts = Object.entries(locationMap).sort((a, b) => b[1] - a[1]);
  const hoursDistribution = Object.entries(hoursMap)
    .map(([label, value]) => ({ label, value }))
    .sort((a, b) => (a.label === "Unknown" ? 1 : b.value - a.value));

  const busiestEntry =
    hoursDistribution.length > 0
      ? hoursDistribution.reduce(
          (prev, current) => (current.value > prev.value ? current : prev),
          hoursDistribution[0]
        )
      : { label: "N/A", value: 0 };

  const longestCallEntry = data.reduce(
    (prev, record, index) => {
      if (durations[index] > prev.duration) {
        return {
          duration: durations[index],
          detail: sanitizeNumber(record)
        };
      }
      return prev;
    },
    { duration: 0, detail: "" }
  );

  const flaggedCalls = data.reduce<string[]>((acc, record, index) => {
    if (durations[index] > 3600) {
      acc.push(
        `${sanitizeNumber(record)} – ${Math.round(durations[index] / 60)} মিনিট (${getLocationLabel(record)})`
      );
    }
    return acc;
  }, []);

  return {
    totalCalls: data.length,
    totalDurationMinutes,
    averageDurationSec: Math.round(averageDurationSeconds),
    topNumbers,
    busiestHourLabel:
      busiestEntry.value > 0 ? `${busiestEntry.label} (প্রায় ${busiestEntry.value} কল)` : "N/A",
    hoursDistribution,
    locationCounts,
    topLocationLabel:
      locationCounts.length > 0
        ? `${locationCounts[0][0]} (${locationCounts[0][1]} কল)`
        : "লোকেশন ডেটা নেই",
    longestCall:
      longestCallEntry.duration > 0
        ? {
            label: `${Math.round(longestCallEntry.duration / 60)} মিনিট`,
            durationMinutes: Math.round(longestCallEntry.duration / 60),
            detail: longestCallEntry.detail || "অজানা"
          }
        : null,
    flaggedCalls
  };
};

const generateNarrative = (stats?: Stats | null) => {
  if (!stats) return "";
  const top = stats.topNumbers[0];
  const flaggedStatement = stats.flaggedCalls.length
    ? `${stats.flaggedCalls.length}টি দীর্ঘ কল চিহ্নিত করা হয়েছে।`
    : "দীর্ঘ কল বা অস্বাভাবিক প্যাটার্ন পাওয়া যায়নি।";
  return [
    `এই ফাইলটি মোট ${stats.totalCalls}টি কল ধারণ করে, মোট ${stats.totalDurationMinutes} মিনিট, গড় দৈর্ঘ্য ${stats.averageDurationSec} সেকেন্ড।`,
    top ? `টপ কন্টাক্ট ${top[0]} (${top[1]} বার)` : "টপ কন্টাক্ট নির্ধারণ করা যায়নি।",
    `সর্বোচ্চ কল ${stats.busiestHourLabel} এ হয়েছে।`,
    flaggedStatement
  ].join(" ");
};

const simulateAgentResponse = (
  question: string,
  stats?: Stats | null,
  narrative?: string,
  personaLabel?: string
) => {
  if (!stats) {
    return (personaLabel ? `${personaLabel} · ` : "") + "প্রথমে ফাইল আপলোড করুন, তারপর আমি ডেটা বিশ্লেষণ করতে পারব।";
  }
  const normalized = question.toLowerCase();
  if (normalized.includes("সবচে") || normalized.includes("top")) {
    const top = stats.topNumbers[0];
    return (
      personaLabel ? `${personaLabel} · ` : ""
    ) +
      (top
        ? `সবচেয়ে বেশি কল ${top[0]} নম্বরে গিয়ে ${top[1]} বার রেকর্ড হয়েছে।`
        : "টপ নম্বর নির্ধারণ করা যায়নি।");
  }
  if (normalized.includes("রাত") || normalized.includes("evening")) {
    const nightItems = stats.hoursDistribution
      .filter(item => item.label >= "20:00" || item.label === "Unknown")
      .map(item => `${item.label} (${item.value} কল)`);
    return (
      personaLabel ? `${personaLabel} · ` : ""
    ) +
      `রাতের সময় ${nightItems.join(", ") || "তথ্য সীমিত"}।`;
  }
  if (normalized.includes("সন্দেহ") || normalized.includes("flag") || normalized.includes("অস্বাভাবিক")) {
    return (
      personaLabel ? `${personaLabel} · ` : ""
    ) +
      (stats.flaggedCalls.length
        ? `সতর্কতা: ${stats.flaggedCalls.length}টি দীর্ঘ কল পাওয়া গেছে। ${stats.flaggedCalls[0]} প্রথমটি।`
        : "এই ডেটাতে এখনও কোনো সন্দেহজনক প্যাটার্ন পাওয়া যায়নি।");
  }
  if (normalized.includes("পরামর্শ") || normalized.includes("recommend") || normalized.includes("পদক্ষেপ")) {
    return (
      personaLabel ? `${personaLabel} · ` : ""
    ) +
      `প্রস্তাব: ${stats.topLocationLabel} এবং ${stats.busiestHourLabel} এ নজর রাখুন, এবং ${
        stats.topNumbers[0]?.[0] ?? "প্রধান নম্বর"
      }-এর সাথে যোগাযোগের রেকর্ড মনিটর করুন।`;
  }
  if (normalized.includes("রিপোর্ট") || normalized.includes("report")) {
    return (
      personaLabel ? `${personaLabel} · ` : ""
    ) +
      `রিপোর্ট: ${narrative || "ডেটা প্রস্তুত, ড্যাশবোর্ডে বিস্তারিত দেখুন।"}`;
  }
  return (
    personaLabel ? `${personaLabel} · ` : ""
  ) +
    (narrative || `এই ডেটা ${stats.totalCalls}টি কল নিয়ে গঠিত। প্রয়োজন হলে আরো প্রশ্ন করুন।`);
};

const generateGeneralResponse = (
  question: string,
  persona: AgentPersona,
  stats?: Stats | null
) => {
  const normalized = question.toLowerCase();
  const knowledgeMatch = generalKnowledge.find(item =>
    item.keywords.some(keyword => normalized.includes(keyword))
  );
  if (knowledgeMatch) {
    return `${persona.title} · ${persona.tone} · ${knowledgeMatch.response}`;
  }
  if (stats) {
    return (
      `${persona.title} · ${persona.tone} · ` +
      `আপনার ডেটা থেকে ${stats.topNumbers[0]?.[0] ?? "প্রধান নম্বর"} ${stats.topNumbers[0]?.[1] ?? 0} বার, ${
        stats.busiestHourLabel
      } পিক আওয়ার।`
    );
  }
  return `${persona.title} · ${persona.tone} · আপনার কথা শোনার জন্য প্রস্তুত, শুধু প্রশ্নটি পাঠান।`;
};

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [cdrData, setCdrData] = useState<CdrRecord[]>([]);
  const [activeTab, setActiveTab] = useState<"upload" | "data" | "insights">("upload");
  const [loading, setLoading] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [userInput, setUserInput] = useState("");
  const [agentThinking, setAgentThinking] = useState(false);
  const [locationFilter, setLocationFilter] = useState("সকল");
  const [chatMode, setChatMode] = useState<ChatMode>("cdr");
  const [personaId, setPersonaId] = useState(agentPersonas[0].id);
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  const stats = useMemo(() => computeStats(cdrData), [cdrData]);
  const analysisNarrative = useMemo(() => generateNarrative(stats), [stats]);
  const insights = useMemo(() => {
    if (!stats) return null;
    return {
      summary: analysisNarrative,
      recommendations: [
        stats.flaggedCalls.length
          ? `${stats.flaggedCalls.length}টি দীর্ঘ কল চিহ্নিত, রিভিউ করুন।`
          : "এই ডেটাতে অস্বাভাবিকতা ধরা পড়েনি।",
        stats.topLocationLabel !== "লোকেশন ডেটা নেই"
          ? `${stats.topLocationLabel} থেকে মূল ট্রাফিক।`
          : "লোকেশন ডেটা সীমিত।",
        stats.longestCall
          ? `দীর্ঘতম কল ${stats.longestCall.label} (${stats.longestCall.detail})।`
          : "দীর্ঘতম কল ডেটা পাওয়া যায়নি।"
      ],
      highlight: stats.busiestHourLabel
    };
  }, [stats, analysisNarrative]);

  const activePersona = useMemo(
    () => agentPersonas.find(agent => agent.id === personaId) ?? agentPersonas[0],
    [personaId]
  );

  const locationOptions = useMemo(() => {
    if (!stats) return ["সকল"];
    return ["সকল", ...stats.locationCounts.map(([location]) => location)];
  }, [stats]);

  const filteredRows = useMemo(() => {
    if (locationFilter === "সকল") return cdrData;
    return cdrData.filter(row => getLocationLabel(row) === locationFilter);
  }, [cdrData, locationFilter]);

  const distributionMax =
    stats?.hoursDistribution.reduce((max, item) => Math.max(max, item.value), 0) ?? 1;

  const handleFileUpload = async (event: ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    event.target.value = "";
    if (!selectedFile) return;
    setLoading(true);
    try {
      const text = await selectedFile.text();
      const parsed = parseCsv(text);
      const previewStats = computeStats(parsed);
      setCdrData(parsed);
      setFile(selectedFile);
      setLocationFilter("সকল");
      setActiveTab("data");
      setChatMessages([
        {
          role: "agent",
          content: previewStats
            ? `✅ ${previewStats.totalCalls}টি কল রেকর্ড লোড হয়েছে। ${previewStats.totalDurationMinutes} মিনিটের ইনসাইট প্রস্তুত।`
            : "✅ ডেটা লোড হয়েছে।",
          timestamp: new Date()
        }
      ]);
    } catch (error) {
      alert("ফাইল পড়তে সমস্যা হয়েছে। CSV, XLSX, PDF বা টেক্সট ফরম্যাটে রূপান্তর করে আবার চেষ্টা করুন।");
    } finally {
      setLoading(false);
    }
  };

  const handleAgentQuestion = () => {
    const question = userInput.trim();
    if (!question || agentThinking) return;
    if (chatMode === "cdr" && !stats) {
      alert("প্রথমে CDR ডেটা আপলোড করুন");
      return;
    }
    setChatMessages(prev => [
      ...prev,
      { role: "user", content: question, timestamp: new Date() }
    ]);
    setUserInput("");
    setAgentThinking(true);
    setTimeout(() => {
      const response =
        chatMode === "cdr"
          ? simulateAgentResponse(question, stats, analysisNarrative, activePersona.title)
          : generateGeneralResponse(question, activePersona, stats);
      setChatMessages(prev => [
        ...prev,
        { role: "agent", content: response, timestamp: new Date() }
      ]);
      setAgentThinking(false);
    }, 700);
  };

  const runAutoInsights = () => {
    if (!stats) {
      alert("প্রথমে CDR ডেটা আপলোড করুন");
      return;
    }
    setActiveTab("insights");
    setChatMessages(prev => [
      ...prev,
      {
        role: "agent",
        content: `🤖 ${activePersona.title} দ্রুত ইনসাইট: ${analysisNarrative}`,
        timestamp: new Date()
      }
    ]);
  };

  const handleDownloadSummary = () => {
    if (!stats) return;
    const payload = {
      metadata: {
        calls: stats.totalCalls,
        durationMinutes: stats.totalDurationMinutes,
        generatedAt: new Date().toISOString()
      },
      insights: {
        narrative: analysisNarrative,
        topNumbers: stats.topNumbers,
        busiestHour: stats.busiestHourLabel,
        topLocation: stats.topLocationLabel
      }
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `cdr-summary-${file?.name ?? "report"}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 px-3 py-8">
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-6">
        <header className="rounded-3xl border border-white/5 bg-gradient-to-br from-purple-700 via-indigo-700 to-slate-900 p-6 shadow-2xl shadow-violet-900/30">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-purple-200">Bengali Insight Hub</p>
              <h1 className="text-3xl font-bold text-white">CDR Intelligence &amp; Any-Agent</h1>
              <p className="mt-1 text-sm text-purple-100/80">
                যেকোনো ফরম্যাট ফাইল আপলোড করে ডেটা বিশ্লেষণ করুন আর একটি শক্তিশালী এজেন্টের সঙ্গে যেকোনো চ্যাট করুন।
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={runAutoInsights}
                disabled={!stats}
                className="flex items-center gap-2 rounded-full bg-gradient-to-r from-emerald-500 to-cyan-500 px-4 py-2 text-sm font-semibold text-slate-900 disabled:opacity-50"
              >
                <Zap className="h-4 w-4" />
                অটোমেটেড ইনসাইট
              </button>
              <button
                onClick={handleDownloadSummary}
                disabled={!stats}
                className="flex items-center gap-2 rounded-full border border-white/30 px-4 py-2 text-sm font-semibold text-white hover:border-white"
              >
                <Download className="h-4 w-4" />
                ডাউনলোড সারাংশ
              </button>
            </div>
          </div>
        </header>

        <div className="grid gap-6 lg:grid-cols-[2fr,1fr]">
          <section className="space-y-6">
            <div className="rounded-3xl border border-white/5 bg-slate-900/80 p-6 shadow-2xl shadow-black/40">
              <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div>
                  <p className="text-xs uppercase tracking-[0.4em] text-slate-400">ডেটা, ইনসাইট, মেসেজ</p>
                  <h2 className="text-2xl font-semibold text-white">ফাইল থেকে হৃদয়স্পর্শী ইনসাইট</h2>
                </div>
                <div className="flex flex-wrap gap-2">
                  {[
                    { id: "upload", label: "আপলোড", icon: Upload },
                    { id: "data", label: "ডেটা", icon: BarChart3 },
                    { id: "insights", label: "ইনসাইট", icon: TrendingUp }
                  ].map(tab => (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setActiveTab(tab.id as "upload" | "data" | "insights")}
                      className={`flex items-center gap-2 rounded-2xl px-4 py-2 text-sm font-semibold transition-colors ${
                        activeTab === tab.id
                          ? "bg-gradient-to-r from-purple-600 to-blue-600 text-white"
                          : "bg-slate-800/70 text-slate-300 hover:bg-slate-800"
                      }`}
                    >
                      <tab.icon className="h-4 w-4" />
                      {tab.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-8 space-y-8">
                {activeTab === "upload" && (
                  <div className="space-y-6">
                    <div className={`rounded-2xl border border-dashed border-white/20 bg-slate-900/60 p-8 text-center`}>
                      <Upload className="mx-auto h-12 w-12 text-purple-400" />
                      <h3 className="mt-4 text-xl font-semibold text-white">CDR ফাইল আপলোড করুন</h3>
                      <p className="mt-2 text-sm text-slate-400">
                        CSV, XLSX, PDF, বা যেকোনো কল-ডিটেইল ফাইল আপলোড করুন। বড় ফাইল হলে কিছু সেকেন্ড লাগতে পারে।
                      </p>
                      <input
                        id="cdr-upload"
                        type="file"
                        accept="*/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                      <label
                        htmlFor="cdr-upload"
                        className="mt-4 inline-flex cursor-pointer items-center justify-center gap-2 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 px-6 py-2 text-sm font-semibold text-white shadow-lg shadow-purple-800/40"
                      >
                        <Upload className="h-4 w-4" />
                        ফাইল নির্বাচন করুন
                      </label>
                      {loading && (
                        <p className="mt-2 text-xs text-slate-400">লোড হচ্ছে, অপেক্ষা করুন...</p>
                      )}
                      {file && !loading && (
                        <p className="mt-2 text-xs text-emerald-300">✓ {file.name} প্রস্তুত</p>
                      )}
                    </div>

                  </div>
                )}

                {activeTab === "data" && (
                  <div className="space-y-8">
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                      <div className="rounded-2xl bg-gradient-to-br from-indigo-600 to-purple-600 p-4 text-white shadow-xl">
                        <div className="flex items-center gap-2 text-sm opacity-90">
                          <Phone className="h-5 w-5" />
                          মোট কল
                        </div>
                        <p className="mt-2 text-3xl font-bold">{stats?.totalCalls ?? 0}</p>
                        <p className="text-xs uppercase tracking-widest">রেকর্ডেড</p>
                      </div>
                      <div className="rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-500 p-4 text-white shadow-xl">
                        <div className="flex items-center gap-2 text-sm opacity-90">
                          <Clock className="h-5 w-5" />
                          মোট মিনিট
                        </div>
                        <p className="mt-2 text-3xl font-bold">{stats?.totalDurationMinutes ?? 0}</p>
                        <p className="text-xs uppercase tracking-widest">স্বয়ংক্রিয় হিসাব</p>
                      </div>
                      <div className="rounded-2xl bg-gradient-to-br from-purple-500 to-fuchsia-500 p-4 text-white shadow-xl">
                        <div className="flex items-center gap-2 text-sm opacity-90">
                          <TrendingUp className="h-5 w-5" />
                          গড় সময়
                        </div>
                        <p className="mt-2 text-3xl font-bold">{stats?.averageDurationSec ?? 0}s</p>
                        <p className="text-xs uppercase tracking-widest">সেকেন্ড</p>
                      </div>
                      <div className="rounded-2xl bg-gradient-to-br from-orange-500 to-amber-500 p-4 text-white shadow-xl">
                        <div className="flex items-center gap-2 text-sm opacity-90">
                          <PieChart className="h-5 w-5" />
                          টপ কন্টাক্ট
                        </div>
                        <p className="mt-2 text-3xl font-bold">{stats?.topNumbers[0]?.[0] ?? "N/A"}</p>
                        <p className="text-xs uppercase tracking-widest">{stats?.topNumbers[0]?.[1] ?? 0} কল</p>
                      </div>
                    </div>

                    <div className="rounded-2xl border border-white/5 bg-slate-900/60 p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-sm text-slate-300">
                          <Search className="h-4 w-4" />
                          <span>লোকেশন ফিল্টার</span>
                        </div>
                        <select
                          value={locationFilter}
                          onChange={event => setLocationFilter(event.target.value)}
                          className="rounded-full border border-white/10 bg-slate-900/70 px-3 py-1 text-sm text-white"
                        >
                          {locationOptions.map(option => (
                            <option
                              key={option}
                              value={option}
                              className="bg-slate-900 text-xs text-white"
                            >
                              {option}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="mt-5 space-y-2">
                        {stats?.hoursDistribution.slice(0, 6).map(item => (
                          <div
                            key={item.label}
                            className="flex items-center gap-3 text-xs text-slate-300"
                          >
                            <span className="w-14 text-left text-white">{item.label}</span>
                            <div className="flex-1 rounded-full bg-slate-800/70">
                              <div
                                className="h-2 rounded-full bg-gradient-to-r from-purple-500 to-blue-500"
                                style={{ width: `${Math.max(8, (item.value / (distributionMax || 1)) * 100)}%` }}
                              />
                            </div>
                            <span className="w-12 text-right">{item.value} কল</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="rounded-2xl border border-white/5 bg-slate-900/60 p-4">
                      <h3 className="text-lg font-semibold text-white">
                        ডেটা প্রিভিউ ({filteredRows.length})
                      </h3>
                      <div className="mt-4 overflow-auto rounded-xl border border-white/5 bg-black/20">
                        <table className="w-full text-xs">
                          <thead className="bg-slate-900/60 text-slate-300">
                            <tr>
                              {(filteredRows[0] ? Object.keys(filteredRows[0]) : []).map(header => (
                                <th key={header} className="px-3 py-2 text-left font-semibold">
                                  {header}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {filteredRows.slice(0, 12).map((row, index) => (
                              <tr key={`${index}-${row.Caller ?? index}`} className="border-b border-white/5 hover:bg-white/5">
                                {Object.values(row).map((value, cellIndex) => (
                                  <td key={`${index}-${cellIndex}`} className="px-3 py-2 text-slate-200">
                                    {value || <span className="text-slate-500">—</span>}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === "insights" && (
                  <div className="space-y-6">
                    {insights && stats ? (
                      <>
                        <div className="rounded-2xl bg-gradient-to-br from-purple-700 to-slate-900 p-5 text-slate-50 shadow-lg">
                          <div className="flex items-center gap-2 text-sm uppercase tracking-widest text-slate-200">
                            <Bot className="h-5 w-5" />
                            AI এজেন্ট সারাংশ
                          </div>
                          <p className="mt-4 text-base leading-relaxed text-slate-100">{insights.summary}</p>
                          <p className="mt-3 text-xs uppercase tracking-widest text-slate-300">{insights.highlight}</p>
                        </div>

                        <div className="grid gap-4 md:grid-cols-2">
                          <div className="rounded-2xl border border-white/5 bg-slate-900/60 p-4">
                            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-slate-400">
                              <BarChart3 className="h-4 w-4" />
                              সময় ভিত্তিক প্যাটার্ন
                            </div>
                            <div className="mt-3 space-y-2 text-sm text-slate-200">
                              {stats.hoursDistribution.slice(0, 5).map(item => (
                                <div key={item.label} className="flex items-center justify-between">
                                  <span>{item.label}</span>
                                  <span className="text-slate-300">{item.value} কল</span>
                                </div>
                              ))}
                            </div>
                          </div>
                          <div className="rounded-2xl border border-white/5 bg-slate-900/60 p-4">
                            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-slate-400">
                              <MapPin className="h-4 w-4" />
                              এरिया হাইলাইট
                            </div>
                            <div className="mt-3 space-y-2 text-sm text-slate-200">
                              {stats.locationCounts.slice(0, 4).map(([location, count]) => (
                                <div key={location} className="flex items-center justify-between">
                                  <span>{location}</span>
                                  <span className="text-slate-300">{count} কল</span>
                                </div>
                              ))}
                            </div>
                            <div className="mt-4 flex items-center justify-between text-xs text-slate-300">
                              <div className="flex items-center gap-1">
                                <Clock className="h-4 w-4" />
                                পিক আওয়ার
                              </div>
                              <span>{stats.busiestHourLabel}</span>
                            </div>
                          </div>
                        </div>

                        <div className="rounded-2xl border border-white/5 bg-slate-900/60 p-4">
                          <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-slate-400">
                            <AlertCircle className="h-4 w-4" />
                            সতর্কতা ও দিনের চলমান ট্র্যাক
                          </div>
                          <div className="mt-3 space-y-2 text-sm text-slate-200">
                            {stats.flaggedCalls.length > 0 ? (
                              stats.flaggedCalls.map(flag => (
                                <p key={flag} className="flex items-center gap-2 text-amber-200">
                                  <span>⚠️</span>
                                  {flag}
                                </p>
                              ))
                            ) : (
                              <p className="text-emerald-300">সবই স্বাভাবিক প্যাটার্নের মধ্যে আছে।</p>
                            )}
                          </div>
                        </div>

                        <div className="rounded-2xl border border-white/5 bg-slate-900/60 p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-slate-400">
                              <TrendingUp className="h-4 w-4" />
                              সুপারিশ
                            </div>
                          </div>
                          <ul className="mt-3 space-y-2 text-sm text-slate-200">
                            {insights.recommendations.map(rec => (
                              <li key={rec} className="flex items-start gap-2">
                                <span className="text-emerald-300">•</span>
                                <span>{rec}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </>
                    ) : (
                      <p className="text-sm text-slate-400">কোনও ডেটা নেই, ফাইল আপলোড করুন তারপর ইনসাইট দেখুন।</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          </section>

          <section className="space-y-6">
            <div className={`flex flex-col gap-3 rounded-3xl border border-white/5 bg-slate-900/80 p-5 shadow-2xl shadow-black/40`}>              
              <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <div className="flex items-center gap-2 text-sm font-semibold uppercase tracking-[0.4em] text-slate-300">
                    <MessageCircle className="h-5 w-5" />
                    AI এজেন্ট চ্যাট
                  </div>
                  <p className="text-xs text-slate-400">{activePersona.title} · {activePersona.tagline}</p>
                </div>
                <div className="flex flex-wrap gap-2 text-xs">
                  {chatModes.map(mode => (
                    <button
                      key={mode.id}
                      onClick={() => setChatMode(mode.id)}
                      className={`rounded-full px-3 py-1 font-semibold transition-colors ${
                        chatMode === mode.id
                          ? "bg-gradient-to-r from-purple-600 to-blue-600 text-white"
                          : "border border-white/20 text-slate-200 hover:border-white"
                      }`}
                    >
                      {mode.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <label className="text-xs uppercase tracking-[0.3em] text-slate-400">
                  এজেন্ট পারসোনা
                </label>
                <div className="flex items-center gap-2 text-sm">
                  <select
                    value={personaId}
                    onChange={event => setPersonaId(event.target.value)}
                    className="flex-1 rounded-full border border-white/20 bg-slate-950/70 px-3 py-1 text-sm text-white outline-none"
                  >
                    {agentPersonas.map(agent => (
                      <option key={agent.id} value={agent.id}>{agent.title}</option>
                    ))}
                  </select>
                  <span className="text-xs text-slate-400">{activePersona.tone}</span>
                </div>
              </div>

              <div className="flex-1 space-y-4 overflow-y-auto rounded-2xl bg-slate-950/40 p-4" style={{ maxHeight: 500 }}>
                {chatMessages.length === 0 && (
                  <div className="flex flex-col items-center gap-2 text-center text-slate-400">
                    <Bot className="h-10 w-10 text-slate-600" />
                    <p>আপনার প্রশ্ন এখানে লিখুন, আমি যেকোনো চ্যাটে সাড়া দেবো।</p>
                    <p className="text-[11px] text-slate-500">ডেটাৃ পাওয়া না থাকলেও জেনারেল কথাবার্তা চালাবে।</p>
                  </div>
                )}
                {chatMessages.map((msg, idx) => (
                  <div
                    key={`${idx}-${msg.timestamp.getTime()}`}
                    className={`flex gap-2 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    {msg.role === "agent" && (
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-purple-600 to-blue-600 text-white">
                        <Bot className="h-4 w-4" />
                      </div>
                    )}
                    <div
                      className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                        msg.role === "user" ? "bg-blue-600 text-white" : "bg-slate-900/80 text-slate-100"
                      }`}
                    >
                      <p className="whitespace-pre-wrap">{msg.content}</p>
                      <p className="mt-1 text-[10px] uppercase tracking-widest text-slate-400">
                        {msg.timestamp.toLocaleTimeString("bn-BD", { hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                    {msg.role === "user" && (
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-white">
                        <User className="h-4 w-4" />
                      </div>
                    )}
                  </div>
                ))}
                {agentThinking && (
                  <div className="flex items-center gap-2">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-purple-600 to-blue-600 text-white">
                      <Bot className="h-4 w-4" />
                    </div>
                    <div className="rounded-2xl bg-slate-900/80 px-4 py-3 text-sm text-slate-300">
                      <div className="flex items-center gap-1">
                        <span className="h-2 w-2 animate-bounce rounded-full bg-slate-400"></span>
                        <span className="h-2 w-2 animate-bounce rounded-full bg-slate-400 delay-200"></span>
                        <span className="h-2 w-2 animate-bounce rounded-full bg-slate-400 delay-400"></span>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>

              <div className="rounded-2xl border border-white/5 p-3">
                <p className="text-xs uppercase tracking-widest text-slate-400">দ্রুত প্রশ্ন</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {quickQuestions.slice(0, 4).map((question, index) => (
                    <button
                      key={index}
                      onClick={() => setUserInput(question)}
                      className="rounded-full border border-white/10 px-3 py-1 text-xs text-slate-200 hover:border-white"
                    >
                      {question}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-3">
                <input
                  type="text"
                  value={userInput}
                  onChange={event => setUserInput(event.target.value)}
                  onKeyDown={event => event.key === "Enter" && handleAgentQuestion()}
                  placeholder={
                    chatMode === "cdr"
                      ? "ডেটা-ভিত্তিক প্রশ্ন লিখুন..."
                      : "সাধারণ কোনো প্রশ্ন, টিপস বা চ্যাট..."
                  }
                  className="flex-1 rounded-2xl border border-white/10 bg-slate-900/60 px-4 py-2 text-sm text-slate-100 outline-none focus:border-blue-400"
                  disabled={(chatMode === "cdr" && !stats) || agentThinking}
                />
                <button
                  onClick={handleAgentQuestion}
                  disabled={agentThinking || (chatMode === "cdr" && !stats) || !userInput.trim()}
                  className="rounded-2xl bg-gradient-to-br from-purple-600 to-blue-600 px-3 py-2 text-white disabled:opacity-40"
                >
                  <Send className="h-5 w-5" />
                </button>
              </div>
            </div>

            <div className="space-y-3 rounded-3xl border border-white/5 bg-slate-900/80 p-5 shadow-2xl shadow-black/40">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs uppercase tracking-widest text-slate-400">সারসংক্ষেপ</p>
                  <h3 className="text-lg font-semibold text-white">রিয়েল-টাইম ডেটা</h3>
                </div>
                <TrendingUp className="h-5 w-5 text-emerald-400" />
              </div>
              <p className="text-sm text-slate-300">{analysisNarrative || "সারাংশ প্রস্তুত হতে ডেটা আপলোড করুন।"}</p>
              <div className="grid gap-3 rounded-2xl border border-white/5 bg-slate-950/30 p-4 text-sm text-slate-200">
                <div className="flex items-center justify-between">
                  <span>পিক আওয়ার</span>
                  <span className="text-emerald-300">{stats?.busiestHourLabel ?? "N/A"}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>টাইম জোন</span>
                  <span>{stats?.hoursDistribution[0]?.label ?? "N/A"}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>সর্বোচ্চ লোকেশন</span>
                  <span className="text-slate-100">{stats?.topLocationLabel ?? "N/A"}</span>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
